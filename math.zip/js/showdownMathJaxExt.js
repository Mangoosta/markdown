showdown.extension('MathJaxExt', function() {
    var matches = [];
    return [
        { 
            type: 'lang',
            regex: /%mathstart%([^]+?)%mathend%/gi,
            replace: function(s, match) { 
                matches.push(match);
                var n = matches.length - 1;
                return '%PLACEHOLDER' + n + '%';
            }
        },
        {
            type: 'output',
            filter: function (text) {
                for (var i=0; i< matches.length; ++i) {
                    var pat = '<p>%PLACEHOLDER' + i + '% *<\/p>';
                    text = text.replace(new RegExp(pat, 'gi'), matches[i]);
                }
                matches = [];
                return text;
            }
        }
    ]
});

$(document).ready(function() {
    var url = window.location.pathname;
    var array = url.split('/');
    var filename = array[array.length-1].split('.')[0]+".md";
    showdown.setOption("tables",true);

    $("body").load(filename, function(responseTxt, statusTxt, xhr){
        if(statusTxt == "success"){
            var converter = new showdown.Converter({extensions: ['MathJaxExt']});
            var converted = converter.makeHtml(responseTxt);
            $("body").html(converted);

            var script = document.createElement("script");
            script.type = "text/javascript";
            script.src = "../js/MathJax.js?config=TeX-AMS_HTML-full";
            document.getElementsByTagName("head")[0].appendChild(script);
        }
    });
});